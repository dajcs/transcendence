
const POINTS_HISTORY = [
  { date:'Apr 21, 3:11 AM', type:'Daily Bonus', desc:'', bp:+1, bpBal:20, tp:null, tpBal:2.0 },
  { date:'Apr 21, 3:11 AM', type:'♥+BP', desc:'1 ♥', bp:+1, bpBal:19, tp:null, tpBal:2.0 },
  { date:'Apr 20, 12:31 PM', type:'♥+BP', desc:'1 ♥', bp:+1, bpBal:18, tp:null, tpBal:2.0 },
  { date:'Apr 20, 10:17 AM', type:'Daily Bonus', desc:'', bp:+1, bpBal:17, tp:null, tpBal:2.0 },
  { date:'Apr 17, 1:53 PM', type:'Bet', desc:'—', bp:-1, bpBal:16, tp:null, tpBal:2.0 },
  { date:'Apr 17, 1:55 PM', type:'Bet', desc:'—', bp:-1, bpBal:17, tp:null, tpBal:2.0 },
  { date:'Apr 17, 9:51 AM', type:'Bet', desc:'Rain in Luxembourg', bp:-1, bpBal:18, tp:null, tpBal:2.0 },
  { date:'Apr 16, 12:22 PM', type:'Won', desc:'what', bp:+3, bpBal:18, tp:+1, tpBal:2.0 },
  { date:'Apr 16, 12:18 PM', type:'Daily Bonus', desc:'what', bp:+1, bpBal:16, tp:null, tpBal:1.0 },
];

const Profile = ({ dark }) => {
  const [tab, setTab] = React.useState('points');
  const [editing, setEditing] = React.useState(false);
  const [bio, setBio] = React.useState('');

  const c = dark
    ? { bg:'oklch(14% 0.015 250)', card:'oklch(18% 0.015 250)', border:'oklch(24% 0.015 250)', text:'oklch(95% 0.005 250)', muted:'oklch(60% 0.01 250)', sub:'oklch(22% 0.015 250)' }
    : { bg:'oklch(98% 0.005 250)', card:'#fff', border:'oklch(91% 0.006 250)', text:'#0f0f0f', muted:'oklch(52% 0.01 250)', sub:'oklch(96% 0.005 250)' };

  return (
    <div style={{minHeight:'100vh', background:c.bg}}>
      <div style={{maxWidth:680, margin:'0 auto', padding:'24px 16px'}}>

        {/* Profile card */}
        <div style={{...profileStyles.card, background:c.card, border:`1px solid ${c.border}`, marginBottom:12}}>
          <div style={{display:'flex', alignItems:'flex-start', justifyContent:'space-between'}}>
            <div style={{display:'flex', alignItems:'center', gap:14}}>
              <div style={{width:52, height:52, borderRadius:'50%', background:'var(--accent)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:800, fontSize:22}}>A</div>
              <div>
                <div style={{fontSize:18, fontWeight:700, color:c.text}}>alice</div>
                <div style={{fontSize:12, color:c.muted, marginTop:2}}>Joined Apr 14, 2026</div>
                {bio ? <div style={{fontSize:13, color:c.text, marginTop:6}}>{bio}</div>
                  : <button onClick={() => setEditing(true)} style={{background:'none', border:'none', color:'var(--accent)', fontSize:12, cursor:'pointer', padding:0, marginTop:4}}>+ Add bio</button>}
              </div>
            </div>
            <button onClick={() => setEditing(!editing)} style={{background:'none', border:`1px solid ${c.border}`, borderRadius:8, padding:'6px 10px', cursor:'pointer', color:c.muted, fontSize:12}}>
              Edit profile
            </button>
          </div>
          {editing && (
            <div style={{marginTop:12, display:'flex', gap:8}}>
              <input value={bio} onChange={e=>setBio(e.target.value)} placeholder="Write a short bio…"
                style={{flex:1, border:`1px solid ${c.border}`, borderRadius:8, padding:'8px 12px', fontSize:13, background:c.sub, color:c.text, outline:'none'}} />
              <button onClick={()=>setEditing(false)} style={{background:'var(--accent)', color:'#fff', border:'none', borderRadius:8, padding:'8px 14px', fontSize:13, fontWeight:600, cursor:'pointer'}}>Save</button>
            </div>
          )}
        </div>

        {/* Stats */}
        <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:12}}>
          {[{v:0,l:'Like Points'},{v:2,l:'Truth Points'},{v:17,l:'Total Bets'},{v:'71.4%',l:'Win Rate'}].map((s,i) => (
            <div key={i} style={{...profileStyles.statCard, background:c.card, border:`1px solid ${c.border}`}}>
              <div style={{fontSize:20, fontWeight:800, color:i===3 ? 'oklch(52% 0.18 145)' : c.text}}>{s.v}</div>
              <div style={{fontSize:11, color:c.muted, marginTop:2}}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{display:'flex', borderBottom:`1px solid ${c.border}`, marginBottom:0}}>
          {[['points',"alice's Points"],['bets',"alice's Bets"],['markets',"alice's Markets"]].map(([id,label]) => (
            <button key={id} onClick={() => setTab(id)}
              style={{...profileStyles.tab, color: tab===id ? 'var(--accent)' : c.muted,
                borderBottom: tab===id ? '2px solid var(--accent)' : '2px solid transparent',
                fontWeight: tab===id ? 600 : 400, background:'none'}}>
              {label}
            </button>
          ))}
        </div>

        {tab === 'points' && (
          <div style={{background:c.card, border:`1px solid ${c.border}`, borderTop:'none', borderRadius:'0 0 10px 10px', overflow:'hidden'}}>
            <div style={{display:'grid', gridTemplateColumns:'140px 100px 1fr 50px 55px 38px 55px', gap:0, padding:'8px 14px', borderBottom:`1px solid ${c.border}`, background:c.sub}}>
              {['Date ↓','Type','Description','BP','BP Bal.','TP','TP Bal.'].map(h => (
                <span key={h} style={{fontSize:11, fontWeight:600, color:c.muted}}>{h}</span>
              ))}
            </div>
            {POINTS_HISTORY.map((row, i) => (
              <div key={i} style={{display:'grid', gridTemplateColumns:'140px 100px 1fr 50px 55px 38px 55px', gap:0, padding:'9px 14px', borderBottom: i<POINTS_HISTORY.length-1 ? `1px solid ${c.border}` : 'none', alignItems:'center'}}>
                <span style={{fontSize:11, color:c.muted}}>{row.date}</span>
                <span>
                  <span style={{fontSize:11, fontWeight:600, padding:'2px 7px', borderRadius:12,
                    background: row.type==='Won' ? 'oklch(94% 0.04 145)' : row.type==='Bet' ? 'oklch(96% 0.04 25)' : row.type.includes('♥') ? 'oklch(95% 0.04 310)' : 'oklch(95% 0.02 250)',
                    color: row.type==='Won' ? 'oklch(42% 0.16 145)' : row.type==='Bet' ? 'oklch(50% 0.18 25)' : row.type.includes('♥') ? 'oklch(50% 0.18 310)' : c.muted}}>
                    {row.type}
                  </span>
                </span>
                <span style={{fontSize:12, color:c.muted}}>{row.desc || '—'}</span>
                <span style={{fontSize:12, fontWeight:700, color: row.bp>0 ? 'oklch(52% 0.18 145)' : 'oklch(55% 0.2 25)'}}>{row.bp>0?'+':''}{row.bp}.0</span>
                <span style={{fontSize:12, color:c.text}}>{row.bpBal}.0</span>
                <span style={{fontSize:12, color: row.tp ? 'oklch(52% 0.18 145)' : c.muted}}>{row.tp ? `+${row.tp}.0` : '—'}</span>
                <span style={{fontSize:12, color:c.text}}>{row.tpBal}</span>
              </div>
            ))}
          </div>
        )}
        {tab === 'bets' && (
          <div style={{background:c.card, border:`1px solid ${c.border}`, borderTop:'none', borderRadius:'0 0 10px 10px', padding:'32px 16px', textAlign:'center', color:c.muted, fontSize:13}}>
            No bets yet.</div>
        )}
        {tab === 'markets' && (
          <div style={{background:c.card, border:`1px solid ${c.border}`, borderTop:'none', borderRadius:'0 0 10px 10px', padding:'32px 16px', textAlign:'center', color:c.muted, fontSize:13}}>
            No markets created yet.</div>
        )}
      </div>
    </div>
  );
};

const profileStyles = {
  card: { padding:'18px', borderRadius:10 },
  statCard: { padding:'14px', borderRadius:10, textAlign:'center' },
  tab: { padding:'11px 16px', border:'none', cursor:'pointer', fontSize:13, transition:'all 0.15s', whiteSpace:'nowrap' },
};

Object.assign(window, { Profile });
