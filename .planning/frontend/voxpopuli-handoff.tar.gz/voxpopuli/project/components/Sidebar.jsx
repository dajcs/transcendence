
const Sidebar = ({ page, setPage, dark, setDark }) => {
  const user = { name: 'alice', bp: 20, tp: 2 };
  const nav = [
    { id: 'markets', label: 'Markets', icon: <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M3 3v18h18"/><path d="m7 16 4-4 4 4 4-4"/></svg> },
    { id: 'friends', label: 'Friends', icon: <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg> },
    { id: 'chat', label: 'Chat', icon: <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> },
    { id: 'profile', label: 'Profile', icon: <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> },
    { id: 'settings', label: 'Settings', icon: <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83"/></svg> },
  ];
  const c = dark ? sidebarStyles.dark : sidebarStyles.light;
  return (
    <aside style={{...sidebarStyles.base, background: c.bg, borderRight: c.border}}>
      <div style={sidebarStyles.logo} onClick={() => setPage('markets')}>
        <div style={{...sidebarStyles.logoMark, background: 'var(--accent)'}}>V</div>
        <span style={{fontWeight:700, fontSize:15, letterSpacing:'-0.02em', color: c.text}}>Vox Populi</span>
      </div>
      <nav style={{flex:1}}>
        {nav.map(n => (
          <button key={n.id} onClick={() => setPage(n.id)}
            style={{...sidebarStyles.navBtn, color: page===n.id ? 'var(--accent)' : c.muted,
              background: page===n.id ? 'var(--accent-soft)' : 'transparent',
              fontWeight: page===n.id ? 600 : 400}}>
            {n.icon} {n.label}
          </button>
        ))}
      </nav>
      <div style={sidebarStyles.bottom}>
        <div style={{...sidebarStyles.statPills}}>
          <span style={{...sidebarStyles.pill, background: 'var(--accent-soft)', color:'var(--accent)'}}>
            ♦ {user.bp} BP
          </span>
          <span style={{...sidebarStyles.pill, background:'oklch(96% 0.02 145)', color:'oklch(42% 0.16 145)'}}>
            ✓ {user.tp} TP
          </span>
        </div>
        <button onClick={() => setDark(!dark)} style={{...sidebarStyles.themeBtn, color: c.muted}} title="Toggle theme">
          {dark ? '☀' : '☾'}
        </button>
      </div>
      <div style={{...sidebarStyles.userRow, borderTop: c.border}} onClick={() => setPage('profile')}>
        <div style={sidebarStyles.avatar}>{user.name[0].toUpperCase()}</div>
        <div>
          <div style={{fontSize:13, fontWeight:600, color: c.text}}>{user.name}</div>
          <div style={{fontSize:11, color: c.muted}}>View profile</div>
        </div>
      </div>
    </aside>
  );
};

const sidebarStyles = {
  base: { width: 220, display:'flex', flexDirection:'column', height:'100vh', position:'fixed', top:0, left:0, zIndex:100, transition:'background 0.2s' },
  logo: { padding:'20px 16px 16px', display:'flex', alignItems:'center', gap:10, cursor:'pointer' },
  logoMark: { width:30, height:30, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:800, fontSize:15 },
  navBtn: { width:'100%', display:'flex', alignItems:'center', gap:10, padding:'10px 16px', border:'none', borderRadius:8, cursor:'pointer', textAlign:'left', fontSize:14, transition:'all 0.15s', margin:'1px 0' },
  bottom: { padding:'8px 16px', display:'flex', alignItems:'center', justifyContent:'space-between' },
  statPills: { display:'flex', gap:4 },
  pill: { fontSize:11, fontWeight:600, padding:'3px 8px', borderRadius:20 },
  themeBtn: { background:'none', border:'none', cursor:'pointer', fontSize:16, padding:4 },
  userRow: { padding:'12px 16px', display:'flex', alignItems:'center', gap:10, cursor:'pointer', marginTop:'auto' },
  avatar: { width:32, height:32, borderRadius:'50%', background:'var(--accent)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, fontSize:14 },
  light: { bg:'#fff', border:'1px solid oklch(92% 0.005 250)', text:'#0f0f0f', muted:'oklch(55% 0.01 250)' },
  dark: { bg:'oklch(14% 0.015 250)', border:'1px solid oklch(22% 0.015 250)', text:'oklch(95% 0.005 250)', muted:'oklch(60% 0.01 250)' },
};

Object.assign(window, { Sidebar });
