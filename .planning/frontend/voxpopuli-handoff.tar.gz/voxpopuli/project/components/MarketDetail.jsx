
const CHOICES = [
  { name: 'Rust', votes: 1, pct: 25, color: 'oklch(58% 0.22 40)' },
  { name: 'Go', votes: 1, pct: 25, color: 'oklch(56% 0.2 205)' },
  { name: 'C++', votes: 1, pct: 25, color: 'oklch(55% 0.2 270)' },
  { name: 'Zig', votes: 0, pct: 0, color: 'oklch(56% 0.18 160)' },
  { name: 'Carbon', votes: 1, pct: 25, color: 'oklch(58% 0.2 310)' },
];

const PARTICIPANTS = [
  { user:'hugo', side:'C++', stake:1, when:'Apr 14, 5:35 PM', color:'oklch(55% 0.2 270)' },
  { user:'claude', side:'GO', stake:1, when:'Apr 14, 5:35 PM', color:'oklch(56% 0.2 205)' },
  { user:'alice', side:'RUST', stake:1, when:'Apr 14, 5:35 PM', color:'oklch(58% 0.22 40)' },
  { user:'bob', side:'CARBON', stake:1, when:'Apr 14, 5:35 PM', color:'oklch(58% 0.2 310)' },
];

const MarketDetail = ({ market, setPage, dark }) => {
  const [liked, setLiked] = React.useState(market?.liked || false);
  const [selectedChoice, setSelectedChoice] = React.useState(null);
  const [stakeInput, setStakeInput] = React.useState('1');
  const [betPlaced, setBetPlaced] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState('odds');

  const m = market || { title: 'Best language for systems programming in 2026?', desc: 'Community vote on safety, performance.', author: 'eve', type: 'multi' };
  const isBinary = m.type === 'binary';

  const c = dark ? { bg:'oklch(14% 0.015 250)', card:'oklch(18% 0.015 250)', border:'oklch(24% 0.015 250)', text:'oklch(95% 0.005 250)', muted:'oklch(60% 0.01 250)', input:'oklch(20% 0.015 250)', sub:'oklch(22% 0.015 250)' }
    : { bg:'oklch(98% 0.005 250)', card:'#fff', border:'oklch(91% 0.006 250)', text:'#0f0f0f', muted:'oklch(52% 0.01 250)', input:'#f8f8fa', sub:'oklch(97% 0.005 250)' };

  const placeBet = () => { if (selectedChoice || isBinary) setBetPlaced(true); };

  return (
    <div style={{minHeight:'100vh', background:c.bg}}>
      <div style={{maxWidth:680, margin:'0 auto', padding:'24px 16px'}}>
        <button onClick={() => setPage('markets')} style={{background:'none', border:'none', cursor:'pointer', color:'var(--accent)', fontSize:13, fontWeight:600, padding:'0 0 16px', display:'flex', alignItems:'center', gap:6}}>
          ← Back to Markets
        </button>

        <div style={{...detailStyles.card, background:c.card, border:`1px solid ${c.border}`, marginBottom:2}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start'}}>
            <span style={{fontSize:12, color:c.muted}}>@{m.author}</span>
            <button onClick={() => setLiked(!liked)} style={{background:'none', border:'none', cursor:'pointer', fontSize:18, color: liked ? 'oklch(58% 0.22 25)' : c.muted}}>
              {liked ? '♥' : '♡'}
            </button>
          </div>
          <h1 style={{fontSize:20, fontWeight:700, color:c.text, margin:'8px 0 6px', lineHeight:1.3}}>{m.title}</h1>
          <p style={{fontSize:13, color:c.muted, margin:'0 0 4px'}}>{m.desc}</p>
          <p style={{fontSize:12, color:c.muted, margin:0}}>Resolution: StackOverflow 2026 most-loved systems programming language.</p>
        </div>

        <div style={{display:'flex', gap:0, marginBottom:2, borderBottom:`1px solid ${c.border}`}}>
          {['odds','participants','position'].map(t => (
            <button key={t} onClick={() => setActiveTab(t)}
              style={{...detailStyles.tab, color: activeTab===t ? 'var(--accent)' : c.muted,
                borderBottom: activeTab===t ? '2px solid var(--accent)' : '2px solid transparent',
                fontWeight: activeTab===t ? 600 : 400, background: 'none'}}>
              {t.charAt(0).toUpperCase()+t.slice(1)}
            </button>
          ))}
        </div>

        {activeTab === 'odds' && (
          <div style={{...detailStyles.card, background:c.card, border:`1px solid ${c.border}`, borderTop:'none', borderRadius:'0 0 10px 10px'}}>
            <div style={{fontSize:11, fontWeight:700, color:c.muted, textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:14}}>Live Odds</div>
            {isBinary ? (
              <div style={{marginBottom:16}}>
                <div style={{display:'flex', gap:2, height:8, borderRadius:4, overflow:'hidden', marginBottom:8}}>
                  <div style={{flex: m.yes, background:'oklch(52% 0.18 145)', transition:'flex 0.3s'}} />
                  <div style={{flex: m.no, background:'oklch(55% 0.2 25)'}} />
                </div>
                <div style={{display:'flex', justifyContent:'space-between'}}>
                  <span style={{fontSize:14, fontWeight:700, color:'oklch(52% 0.18 145)'}}>YES {m.yes}%</span>
                  <span style={{fontSize:14, fontWeight:700, color:'oklch(55% 0.2 25)'}}>NO {m.no}%</span>
                </div>
              </div>
            ) : (
              <div style={{display:'flex', flexDirection:'column', gap:10}}>
                {CHOICES.map(ch => (
                  <div key={ch.name} onClick={() => !betPlaced && setSelectedChoice(ch.name)}
                    style={{cursor: betPlaced ? 'default' : 'pointer'}}>
                    <div style={{display:'flex', justifyContent:'space-between', marginBottom:4}}>
                      <span style={{fontSize:13, fontWeight:selectedChoice===ch.name ? 700 : 500, color: selectedChoice===ch.name ? ch.color : c.text}}>{ch.name}</span>
                      <span style={{fontSize:12, color:c.muted}}>{ch.votes} votes ({ch.pct}%)</span>
                    </div>
                    <div style={{height:6, borderRadius:3, background: dark ? 'oklch(26% 0.01 250)' : 'oklch(93% 0.005 250)', overflow:'hidden'}}>
                      <div style={{height:'100%', width:`${ch.pct||2}%`, background: selectedChoice===ch.name ? ch.color : (dark?'oklch(50% 0.12 250)':'oklch(65% 0.1 250)'), borderRadius:3, transition:'all 0.3s'}} />
                    </div>
                  </div>
                ))}
                <div style={{fontSize:12, color:c.muted, marginTop:4}}>4 total votes</div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'participants' && (
          <div style={{...detailStyles.card, background:c.card, border:`1px solid ${c.border}`, borderTop:'none', borderRadius:'0 0 10px 10px'}}>
            <div style={{display:'flex', gap:0, marginBottom:16}}>
              {[{v:'4 BP', l:'Total staked'},{v:'1 GO / 1 C++ / 1 CARBON / 1 RUST', l:'Participants'},{v:'1 BP', l:'Avg stake'}].map((s,i) => (
                <div key={i} style={{flex:1, textAlign:'center', padding:'8px 4px', borderRight: i<2 ? `1px solid ${c.border}` : 'none'}}>
                  <div style={{fontSize:13, fontWeight:700, color:c.text}}>{s.v}</div>
                  <div style={{fontSize:11, color:c.muted}}>{s.l}</div>
                </div>
              ))}
            </div>
            <div style={{fontSize:11, color:c.muted, textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:10, display:'grid', gridTemplateColumns:'1fr 80px 70px 1fr', gap:8}}>
              <span>User</span><span>Side</span><span>Stake</span><span style={{textAlign:'right'}}>When</span>
            </div>
            {PARTICIPANTS.map((p,i) => (
              <div key={i} style={{display:'grid', gridTemplateColumns:'1fr 80px 70px 1fr', gap:8, padding:'8px 0', borderTop:`1px solid ${c.border}`, alignItems:'center'}}>
                <span style={{fontSize:13, color:c.text, fontWeight:500}}>{p.user}</span>
                <span style={{fontSize:12, fontWeight:700, color:p.color}}>{p.side}</span>
                <span style={{fontSize:13, color:c.text}}>{p.stake} BP</span>
                <span style={{fontSize:11, color:c.muted, textAlign:'right'}}>{p.when}</span>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'position' && (
          <div style={{...detailStyles.card, background:c.card, border:`1px solid ${c.border}`, borderTop:'none', borderRadius:'0 0 10px 10px'}}>
            <div style={{fontSize:11, fontWeight:700, color:c.muted, textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:12}}>Your Position</div>
            {betPlaced ? (
              <div style={{background:'var(--accent-soft)', borderRadius:8, padding:'12px 16px'}}>
                <div style={{fontSize:13, fontWeight:600, color:'var(--accent)'}}>Choice: {selectedChoice || 'YES'} · Staked: {stakeInput} BP</div>
                <div style={{fontSize:12, color:'var(--accent)', marginTop:4, opacity:0.8}}>Position active. Good luck!</div>
              </div>
            ) : (
              <div>
                <div style={{fontSize:13, color:c.muted, marginBottom:16}}>No position yet. Place a bet below.</div>
                {!isBinary && selectedChoice && (
                  <div style={{background:'var(--accent-soft)', borderRadius:8, padding:'10px 14px', marginBottom:12}}>
                    <span style={{fontSize:13, fontWeight:600, color:'var(--accent)'}}>Selected: {selectedChoice}</span>
                  </div>
                )}
                <div style={{display:'flex', gap:8, alignItems:'center'}}>
                  {isBinary ? (
                    <>
                      <button onClick={() => { setSelectedChoice('YES'); setBetPlaced(true); }} style={{...detailStyles.betBtn, background:'oklch(52% 0.18 145)', flex:1}}>Bet YES</button>
                      <button onClick={() => { setSelectedChoice('NO'); setBetPlaced(true); }} style={{...detailStyles.betBtn, background:'oklch(55% 0.2 25)', flex:1}}>Bet NO</button>
                    </>
                  ) : (
                    <button onClick={placeBet} disabled={!selectedChoice} style={{...detailStyles.betBtn, background: selectedChoice ? 'var(--accent)' : (dark?'oklch(26%0.01 250)':'oklch(88% 0.005 250)'), flex:1, opacity: selectedChoice ? 1 : 0.5, cursor: selectedChoice ? 'pointer' : 'not-allowed'}}>
                      Place Bet {selectedChoice ? `on ${selectedChoice}` : '— select above'}
                    </button>
                  )}
                  <div style={{display:'flex', alignItems:'center', gap:4, border:`1px solid ${c.border}`, borderRadius:8, padding:'0 8px'}}>
                    <input value={stakeInput} onChange={e=>setStakeInput(e.target.value)} style={{width:40, border:'none', background:'transparent', fontSize:14, fontWeight:700, color:'var(--accent)', outline:'none', textAlign:'center'}} />
                    <span style={{fontSize:12, color:c.muted}}>BP</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const detailStyles = {
  card: { padding:'16px', borderRadius:10, marginBottom:0 },
  tab: { padding:'12px 16px', border:'none', cursor:'pointer', fontSize:13, transition:'all 0.15s' },
  betBtn: { color:'#fff', border:'none', borderRadius:8, padding:'10px', fontSize:13, fontWeight:700, cursor:'pointer', transition:'opacity 0.15s' },
};

Object.assign(window, { MarketDetail });
