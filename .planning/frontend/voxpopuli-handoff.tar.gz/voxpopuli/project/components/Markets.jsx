
const MARKETS = [
  { id: 1, author: 'faust', title: 'Stack Overflow questions asked in 2026 (millions)?', desc: 'Total new questions posted on Stack Overflow during calendar year 2026.', type: 'numeric', range: '8–40', votes: 3, comments: 4, upvotes: 2, deadline: 'Apr 14', status: 'pending', liked: false },
  { id: 2, author: 'faust', title: 'Which company will have the most impactful AI release in 2026?', desc: 'Impact measured by media coverage, research citations, and industry adoption.', type: 'multi', choices: 5, votes: 3, comments: 2, upvotes: 2, deadline: 'Apr 14', status: 'pending', liked: false },
  { id: 3, author: 'eve', title: 'Best language for systems programming in 2026?', desc: 'Community vote on safety, performance, and ecosystem maturity.', type: 'multi', choices: 5, votes: 4, comments: 3, upvotes: 2, deadline: 'Apr 14', status: 'pending', liked: false },
  { id: 4, author: 'eve', title: 'Will quantum computing achieve 1000-qubit stable operation by 2027?', desc: 'Stable = sustained computation with error rate below 0.1% per gate.', type: 'binary', yes: 66.7, no: 33.3, votes: 3, comments: 4, upvotes: 1, deadline: 'Apr 14', status: 'pending', liked: false },
  { id: 5, author: 'bob', title: 'Will GPT-5 score above 90% on the MMLU benchmark?', desc: 'Measured on the standard 57-task MMLU evaluation suite.', type: 'binary', yes: 72.0, no: 28.0, votes: 7, comments: 6, upvotes: 5, deadline: 'May 1', status: 'open', liked: true },
  { id: 6, author: 'gina', title: 'Total global EV sales in 2026 (millions)?', desc: 'All battery electric vehicles sold worldwide.', type: 'numeric', range: '14–22', votes: 5, comments: 3, upvotes: 3, deadline: 'Dec 31', status: 'open', liked: false },
];

const Markets = ({ setPage, setMarket, dark }) => {
  const [sort, setSort] = React.useState('Hot');
  const [filter, setFilter] = React.useState('All');
  const [search, setSearch] = React.useState('');
  const [markets, setMarkets] = React.useState(MARKETS);
  const [showCreate, setShowCreate] = React.useState(false);

  const c = dark ? { bg:'oklch(14% 0.015 250)', card:'oklch(18% 0.015 250)', border:'oklch(24% 0.015 250)', text:'oklch(95% 0.005 250)', muted:'oklch(60% 0.01 250)', input:'oklch(20% 0.015 250)' }
    : { bg:'oklch(98% 0.005 250)', card:'#fff', border:'oklch(91% 0.006 250)', text:'#0f0f0f', muted:'oklch(52% 0.01 250)', input:'#fff' };

  const filtered = markets.filter(m => {
    if (search && !m.title.toLowerCase().includes(search.toLowerCase())) return false;
    if (filter === 'Open') return m.status === 'open';
    if (filter === 'Resolved') return m.status === 'resolved';
    if (filter === 'Disputed') return m.status === 'disputed';
    return true;
  });

  const toggleLike = (id, e) => { e.stopPropagation(); setMarkets(ms => ms.map(m => m.id===id ? {...m, liked:!m.liked, upvotes: m.liked ? m.upvotes-1 : m.upvotes+1} : m)); };

  return (
    <div style={{minHeight:'100vh', background: c.bg}}>
      <div style={{maxWidth:680, margin:'0 auto', padding:'24px 16px'}}>
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20}}>
          <h1 style={{fontSize:22, fontWeight:700, color:c.text, margin:0}}>Markets</h1>
          <button onClick={() => setShowCreate(true)} style={marketsStyles.createBtn}>+ Create Market</button>
        </div>

        <div style={{position:'relative', marginBottom:12}}>
          <svg style={{position:'absolute',left:12,top:'50%',transform:'translateY(-50%)',opacity:0.4}} width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search markets…"
            style={{...marketsStyles.searchInput, background:c.input, border:`1px solid ${c.border}`, color:c.text}} />
        </div>

        <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:14, flexWrap:'wrap'}}>
          <div style={{display:'flex', gap:4}}>
            {['Hot','New','Closing'].map(s => (
              <button key={s} onClick={() => setSort(s)}
                style={{...marketsStyles.chip, background: sort===s ? 'var(--accent)' : 'transparent',
                  color: sort===s ? '#fff' : c.muted, border: `1px solid ${sort===s ? 'var(--accent)' : c.border}`}}>
                {s}{s==='Closing' && ' ↑'}
              </button>
            ))}
          </div>
          <div style={{width:1, height:16, background:c.border}} />
          <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
            {['All','My Bets','Open','Disputed','Resolved'].map(f => (
              <button key={f} onClick={() => setFilter(f)}
                style={{...marketsStyles.chip, background: filter===f ? c.border : 'transparent',
                  color: filter===f ? c.text : c.muted, border:`1px solid ${filter===f ? c.border : 'transparent'}`,
                  fontWeight: filter===f ? 600 : 400}}>
                {f}
              </button>
            ))}
          </div>
        </div>

        <div style={{display:'flex', flexDirection:'column', gap:1}}>
          {filtered.map(m => (
            <div key={m.id} onClick={() => { setMarket(m); setPage('detail'); }}
              style={{...marketsStyles.card, background:c.card, border:`1px solid ${c.border}`, cursor:'pointer'}}>
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:4}}>
                <span style={{fontSize:11, color:c.muted}}>@{m.author}</span>
                {m.type==='binary' ? (
                  <div style={{display:'flex', gap:6}}>
                    <span style={{fontSize:11, fontWeight:700, color:'oklch(52% 0.18 145)'}}>YES {m.yes}%</span>
                    <span style={{fontSize:11, fontWeight:700, color:'oklch(55% 0.2 25)'}}>NO {m.no}%</span>
                  </div>
                ) : m.type==='multi' ? (
                  <span style={{fontSize:11, color:'var(--accent)', fontWeight:600}}>{m.choices} choices</span>
                ) : (
                  <span style={{fontSize:11, color:'var(--accent)', fontWeight:600}}>{m.range}</span>
                )}
              </div>
              <div style={{fontSize:15, fontWeight:600, color:c.text, marginBottom:4, lineHeight:1.35}}>{m.title}</div>
              <div style={{fontSize:12, color:c.muted, marginBottom:10, lineHeight:1.4}}>{m.desc}</div>
              {m.type==='binary' && (
                <div style={{marginBottom:10, display:'flex', gap:2}}>
                  <div style={{height:4, borderRadius:'2px 0 0 2px', background:'oklch(52% 0.18 145)', width:`${m.yes}%`, transition:'width 0.3s'}} />
                  <div style={{height:4, borderRadius:'0 2px 2px 0', background:'oklch(55% 0.2 25)', width:`${m.no}%`}} />
                </div>
              )}
              <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
                <div style={{display:'flex', alignItems:'center', gap:12}}>
                  <span style={{...marketsStyles.statusBadge, background: m.status==='open' ? 'oklch(95% 0.04 145)' : 'oklch(97% 0.05 85)',
                    color: m.status==='open' ? 'oklch(42% 0.16 145)' : 'oklch(50% 0.15 80)'}}>
                    {m.status==='open' ? 'Open' : 'Pending Resolution'}
                  </span>
                  <span style={{fontSize:11, color:c.muted}}>closes {m.deadline}</span>
                </div>
                <div style={{display:'flex', alignItems:'center', gap:10}}>
                  <span style={{fontSize:11, color:c.muted}}>{m.votes} votes · {m.comments} comments</span>
                  <button onClick={e => toggleLike(m.id, e)}
                    style={{...marketsStyles.likeBtn, color: m.liked ? 'oklch(58% 0.22 25)' : c.muted}}>
                    {m.liked ? '▲' : '△'} {m.upvotes}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showCreate && <CreateModal dark={dark} c={c} onClose={() => setShowCreate(false)} onAdd={m => { setMarkets(ms => [m, ...ms]); setShowCreate(false); }} />}
    </div>
  );
};

const CreateModal = ({ dark, c, onClose, onAdd }) => {
  const [title, setTitle] = React.useState('');
  const [desc, setDesc] = React.useState('');
  const [type, setType] = React.useState('binary');
  return (
    <div style={marketsStyles.overlay} onClick={onClose}>
      <div style={{...marketsStyles.modal, background: dark ? 'oklch(18% 0.015 250)' : '#fff', border:`1px solid ${c.border}`}} onClick={e=>e.stopPropagation()}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20}}>
          <h2 style={{fontSize:16, fontWeight:700, color:c.text, margin:0}}>Create Market</h2>
          <button onClick={onClose} style={{background:'none', border:'none', cursor:'pointer', color:c.muted, fontSize:18}}>×</button>
        </div>
        <div style={{display:'flex', gap:6, marginBottom:16}}>
          {['binary','multi','numeric'].map(t => (
            <button key={t} onClick={() => setType(t)}
              style={{...marketsStyles.chip, flex:1, justifyContent:'center', background: type===t ? 'var(--accent)' : 'transparent',
                color: type===t ? '#fff' : c.muted, border:`1px solid ${type===t ? 'var(--accent)' : c.border}`, textTransform:'capitalize'}}>
              {t}
            </button>
          ))}
        </div>
        <input placeholder="Market question…" value={title} onChange={e=>setTitle(e.target.value)}
          style={{...marketsStyles.searchInput, background:c.input||'#f5f5f5', border:`1px solid ${c.border}`, color:c.text, marginBottom:10, paddingLeft:12}} />
        <textarea placeholder="Description (optional)" value={desc} onChange={e=>setDesc(e.target.value)}
          style={{...marketsStyles.searchInput, background:c.input||'#f5f5f5', border:`1px solid ${c.border}`, color:c.text, paddingLeft:12, height:70, resize:'none'}} />
        <div style={{display:'flex', gap:8, marginTop:16, justifyContent:'flex-end'}}>
          <button onClick={onClose} style={{...marketsStyles.chip, border:`1px solid ${c.border}`, color:c.muted}}>Cancel</button>
          <button onClick={() => onAdd({ id: Date.now(), author:'alice', title: title||'Untitled Market', desc, type, yes:50, no:50, choices:3, range:'0–100', votes:0, comments:0, upvotes:0, deadline:'TBD', status:'open', liked:false })}
            style={{...marketsStyles.createBtn, fontSize:13}}>Publish</button>
        </div>
      </div>
    </div>
  );
};

const marketsStyles = {
  createBtn: { background:'var(--accent)', color:'#fff', border:'none', borderRadius:8, padding:'8px 16px', fontSize:14, fontWeight:600, cursor:'pointer' },
  searchInput: { width:'100%', padding:'9px 12px 9px 34px', borderRadius:8, fontSize:13, outline:'none', boxSizing:'border-box' },
  chip: { fontSize:12, fontWeight:500, padding:'5px 10px', borderRadius:6, cursor:'pointer', whiteSpace:'nowrap', display:'flex', alignItems:'center', gap:4 },
  card: { padding:'14px 16px', borderRadius:10, transition:'box-shadow 0.15s', marginBottom:2 },
  statusBadge: { fontSize:11, fontWeight:600, padding:'2px 8px', borderRadius:20 },
  likeBtn: { background:'none', border:'none', cursor:'pointer', fontSize:12, fontWeight:600, padding:0 },
  overlay: { position:'fixed', inset:0, background:'rgba(0,0,0,0.4)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000 },
  modal: { borderRadius:14, padding:24, width:440, maxWidth:'90vw' },
};

Object.assign(window, { Markets });
