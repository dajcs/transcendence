
const Settings = ({ dark }) => {
  const [lang, setLang] = React.useState('English');
  const [ai, setAi] = React.useState('platform');
  const [apiKey, setApiKey] = React.useState('');
  const [saved, setSaved] = React.useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = React.useState(false);

  const c = dark
    ? { bg:'oklch(14% 0.015 250)', card:'oklch(18% 0.015 250)', border:'oklch(24% 0.015 250)', text:'oklch(95% 0.005 250)', muted:'oklch(60% 0.01 250)', input:'oklch(22% 0.015 250)', label:'oklch(75% 0.01 250)' }
    : { bg:'oklch(98% 0.005 250)', card:'#fff', border:'oklch(91% 0.006 250)', text:'#0f0f0f', muted:'oklch(52% 0.01 250)', input:'#f8f8fa', label:'oklch(35% 0.01 250)' };

  const save = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  const Section = ({ title, desc, children }) => (
    <div style={{...settingsStyles.section, background:c.card, border:`1px solid ${c.border}`}}>
      <div style={{marginBottom:desc?12:16}}>
        <div style={{fontSize:15, fontWeight:700, color:c.text}}>{title}</div>
        {desc && <div style={{fontSize:13, color:c.muted, marginTop:3}}>{desc}</div>}
      </div>
      {children}
    </div>
  );

  const Radio = ({ value, label, sub, current, onChange }) => (
    <label style={{display:'flex', gap:10, alignItems:'flex-start', cursor:'pointer', marginBottom:12}}>
      <input type="radio" checked={current===value} onChange={() => onChange(value)}
        style={{marginTop:2, accentColor:'var(--accent)'}} />
      <div>
        <div style={{fontSize:13, fontWeight:500, color:c.text}}>{label}</div>
        {sub && <div style={{fontSize:12, color:c.muted, marginTop:1}}>{sub}</div>}
      </div>
    </label>
  );

  return (
    <div style={{minHeight:'100vh', background:c.bg}}>
      <div style={{maxWidth:560, margin:'0 auto', padding:'24px 16px'}}>
        <h1 style={{fontSize:22, fontWeight:700, color:c.text, marginBottom:20}}>Settings</h1>

        <Section title="Language" desc="Choose your preferred language for the interface.">
          <select value={lang} onChange={e=>setLang(e.target.value)}
            style={{border:`1px solid ${c.border}`, borderRadius:8, padding:'8px 12px', fontSize:13, background:c.input, color:c.text, outline:'none', cursor:'pointer'}}>
            {['English','French','German','Spanish','Japanese','Chinese'].map(l => <option key={l}>{l}</option>)}
          </select>
        </Section>

        <Section title="AI Features" desc="Controls the thread summarizer and AI resolution suggestion features.">
          <Radio value="platform" label="Platform default (free, via OpenRouter)" sub="Uses the platform shared key. Subject to daily limits." current={ai} onChange={setAi} />
          <Radio value="disabled" label="Disabled — hide AI features" sub="Summarize and AI suggestion buttons will not appear." current={ai} onChange={setAi} />
          <Radio value="own" label="My own API key" sub="Requests go directly to your provider. No daily limits applied." current={ai} onChange={setAi} />
          {ai === 'own' && (
            <input value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="sk-…" type="password"
              style={{width:'100%', border:`1px solid ${c.border}`, borderRadius:8, padding:'8px 12px', fontSize:13, background:c.input, color:c.text, outline:'none', boxSizing:'border-box', marginBottom:12}} />
          )}
          <button onClick={save} style={{background: saved ? 'oklch(52% 0.18 145)' : 'oklch(18% 0.01 250)', color:'#fff', border:'none', borderRadius:8, padding:'9px 18px', fontSize:13, fontWeight:600, cursor:'pointer', transition:'background 0.2s'}}>
            {saved ? '✓ Saved' : 'Save settings'}
          </button>
        </Section>

        <Section title="Your Data (GDPR)" desc="Export or delete your account data.">
          <div style={{display:'flex', gap:10}}>
            <button style={{background:'var(--accent)', color:'#fff', border:'none', borderRadius:8, padding:'9px 18px', fontSize:13, fontWeight:600, cursor:'pointer'}}>Export My Data</button>
            <button onClick={() => setShowDeleteConfirm(true)} style={{background:'oklch(55% 0.2 25)', color:'#fff', border:'none', borderRadius:8, padding:'9px 18px', fontSize:13, fontWeight:600, cursor:'pointer'}}>Delete My Account</button>
          </div>
          {showDeleteConfirm && (
            <div style={{marginTop:14, background:'oklch(98% 0.04 25)', border:'1px solid oklch(90% 0.08 25)', borderRadius:8, padding:'12px 14px'}}>
              <div style={{fontSize:13, fontWeight:600, color:'oklch(45% 0.2 25)', marginBottom:10}}>⚠ Are you sure? This cannot be undone.</div>
              <div style={{display:'flex', gap:8}}>
                <button onClick={() => setShowDeleteConfirm(false)} style={{border:`1px solid ${c.border}`, background:'transparent', borderRadius:8, padding:'7px 14px', fontSize:13, cursor:'pointer', color:c.muted}}>Cancel</button>
                <button style={{background:'oklch(55% 0.2 25)', color:'#fff', border:'none', borderRadius:8, padding:'7px 14px', fontSize:13, fontWeight:600, cursor:'pointer'}}>Confirm Delete</button>
              </div>
            </div>
          )}
        </Section>

        <Section title="Notifications">
          {[['Market resolved','Get notified when a market you bet on resolves.','notif_resolved'],
            ['New comment','Notify when someone comments on your market.','notif_comment'],
            ['Friend activity','Notify when a friend places a bet.','notif_friend']].map(([label,sub,key]) => (
            <label key={key} style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14, cursor:'pointer'}}>
              <div>
                <div style={{fontSize:13, fontWeight:500, color:c.text}}>{label}</div>
                <div style={{fontSize:12, color:c.muted}}>{sub}</div>
              </div>
              <input type="checkbox" defaultChecked style={{accentColor:'var(--accent)', width:16, height:16}} />
            </label>
          ))}
        </Section>
      </div>
    </div>
  );
};

const settingsStyles = {
  section: { padding:'18px', borderRadius:10, marginBottom:10 },
};

Object.assign(window, { Settings });
