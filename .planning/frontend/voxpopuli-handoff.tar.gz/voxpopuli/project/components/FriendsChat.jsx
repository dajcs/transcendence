
const FRIENDS_LIST = [
  { name:'bob', initial:'B', since:'Apr 14, 2026', color:'oklch(56% 0.2 205)' },
  { name:'claude', initial:'C', since:'Apr 14, 2026', color:'oklch(55% 0.2 270)' },
  { name:'gina', initial:'G', since:'Apr 14, 2026', color:'oklch(56% 0.18 160)' },
];

const CHAT_LIST = [
  { name:'bob', initial:'B', last:'Nice, I threw in a no — incumbents don\'t move that fast.', date:'Apr 17', color:'oklch(56% 0.2 205)', unread:0 },
  { name:'gina', initial:'G', last:'Yep. Staked accordingly.', date:'Apr 14', color:'oklch(56% 0.18 160)', unread:2 },
  { name:'claude', initial:'C', last:'I\'m hedging yes. Too much VC pressure on the smaller ones.', date:'Apr 14', color:'oklch(55% 0.2 270)', unread:0 },
  { name:'[deleted]', initial:'?', last:'[deleted]', date:'Apr 17', color:'oklch(55% 0.01 250)', unread:0 },
];

const MESSAGES = {
  bob: [
    { from:'bob', text:'Did you see the quantum computing market?', time:'3:41 PM' },
    { from:'alice', text:'Yeah, voted YES. The hardware roadmaps look solid.', time:'3:43 PM' },
    { from:'bob', text:'Nice, I threw in a no — incumbents don\'t move that fast.', time:'3:44 PM' },
    { from:'alice', text:'Fair. We\'ll see in 2027 👀', time:'3:45 PM' },
  ],
  gina: [
    { from:'gina', text:'Yep. Staked accordingly.', time:'2:12 PM' },
    { from:'alice', text:'Smart. What\'s your read on the AI release market?', time:'2:15 PM' },
  ],
  claude: [
    { from:'claude', text:'I\'m hedging yes. Too much VC pressure on the smaller ones.', time:'11:03 AM' },
  ],
};

const Friends = ({ dark, setPage: _setPage }) => {
  const [tab, setTab] = React.useState('friends');
  const [search, setSearch] = React.useState('');
  const [friends, setFriends] = React.useState(FRIENDS_LIST);

  const c = dark
    ? { bg:'oklch(14% 0.015 250)', card:'oklch(18% 0.015 250)', border:'oklch(24% 0.015 250)', text:'oklch(95% 0.005 250)', muted:'oklch(60% 0.01 250)', input:'oklch(20% 0.015 250)' }
    : { bg:'oklch(98% 0.005 250)', card:'#fff', border:'oklch(91% 0.006 250)', text:'#0f0f0f', muted:'oklch(52% 0.01 250)', input:'#f8f8fa' };

  return (
    <div style={{minHeight:'100vh', background:c.bg}}>
      <div style={{maxWidth:580, margin:'0 auto', padding:'24px 16px'}}>
        <h1 style={{fontSize:22, fontWeight:700, color:c.text, marginBottom:20}}>Friends</h1>

        <div style={{...friendStyles.card, background:c.card, border:`1px solid ${c.border}`, marginBottom:16}}>
          <div style={{fontSize:13, fontWeight:600, color:c.text, marginBottom:8}}>Add Friend</div>
          <div style={{display:'flex', gap:8}}>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by username…"
              style={{flex:1, border:`1px solid ${c.border}`, borderRadius:8, padding:'8px 12px', fontSize:13, background:c.input, color:c.text, outline:'none'}} />
            <button style={{background:'var(--accent)', color:'#fff', border:'none', borderRadius:8, padding:'8px 16px', fontSize:13, fontWeight:600, cursor:'pointer'}}>Send Request</button>
          </div>
        </div>

        <div style={{display:'flex', gap:0, borderBottom:`1px solid ${c.border}`, marginBottom:12}}>
          {[['friends',`All Friends (${friends.length})`],['requests','Requests (0)'],['sent','Sent (0)']].map(([id,label]) => (
            <button key={id} onClick={() => setTab(id)}
              style={{...friendStyles.tab, color: tab===id ? 'var(--accent)' : c.muted,
                borderBottom: tab===id ? '2px solid var(--accent)' : '2px solid transparent',
                fontWeight: tab===id ? 600 : 400, background:'none'}}>
              {label}
            </button>
          ))}
        </div>

        {tab === 'friends' && (
          <div style={{display:'flex', flexDirection:'column', gap:6}}>
            {friends.map((f, i) => (
              <div key={f.name} style={{...friendStyles.card, background:c.card, border:`1px solid ${c.border}`, display:'flex', alignItems:'center', gap:12}}>
                <div style={{width:38, height:38, borderRadius:'50%', background:f.color, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700, fontSize:15, flexShrink:0}}>{f.initial}</div>
                <div style={{flex:1}}>
                  <div style={{fontSize:14, fontWeight:600, color:c.text}}>{f.name}</div>
                  <div style={{fontSize:11, color:c.muted}}>Friends since {f.since}</div>
                </div>
                <div style={{display:'flex', gap:6}}>
                  <button style={friendStyles.msgBtn}>Message</button>
                  <button onClick={() => setFriends(fs => fs.filter((_,j) => j!==i))} style={friendStyles.removeBtn}>Remove</button>
                  <button style={friendStyles.blockBtn}>Block</button>
                </div>
              </div>
            ))}
            {friends.length === 0 && <div style={{textAlign:'center', color:c.muted, fontSize:13, padding:'32px 0'}}>No friends yet. Search for users above!</div>}
          </div>
        )}
        {(tab === 'requests' || tab === 'sent') && (
          <div style={{textAlign:'center', color:c.muted, fontSize:13, padding:'32px 0'}}>No {tab} yet.</div>
        )}
      </div>
    </div>
  );
};

const Chat = ({ dark }) => {
  const [active, setActive] = React.useState('bob');
  const [input, setInput] = React.useState('');
  const [msgs, setMsgs] = React.useState(MESSAGES);

  const c = dark
    ? { bg:'oklch(14% 0.015 250)', card:'oklch(18% 0.015 250)', border:'oklch(24% 0.015 250)', text:'oklch(95% 0.005 250)', muted:'oklch(60% 0.01 250)', input:'oklch(20% 0.015 250)', bubble:'oklch(22% 0.015 250)' }
    : { bg:'oklch(98% 0.005 250)', card:'#fff', border:'oklch(91% 0.006 250)', text:'#0f0f0f', muted:'oklch(52% 0.01 250)', input:'#f8f8fa', bubble:'oklch(95% 0.005 250)' };

  const send = () => {
    if (!input.trim()) return;
    setMsgs(m => ({ ...m, [active]: [...(m[active]||[]), { from:'alice', text:input.trim(), time: new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) }] }));
    setInput('');
  };

  const friend = CHAT_LIST.find(f => f.name === active);

  return (
    <div style={{minHeight:'100vh', background:c.bg, display:'flex'}}>
      <div style={{width:240, background:c.card, borderRight:`1px solid ${c.border}`, display:'flex', flexDirection:'column'}}>
        <div style={{padding:'20px 16px 12px', fontSize:16, fontWeight:700, color:c.text, borderBottom:`1px solid ${c.border}`}}>Messages</div>
        <div style={{flex:1, overflowY:'auto'}}>
          {CHAT_LIST.map(f => (
            <div key={f.name} onClick={() => setActive(f.name)}
              style={{display:'flex', gap:10, padding:'12px 14px', cursor:'pointer', background: active===f.name ? 'var(--accent-soft)' : 'transparent', borderLeft: active===f.name ? '2px solid var(--accent)' : '2px solid transparent'}}>
              <div style={{width:36, height:36, borderRadius:'50%', background:f.color, flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700, fontSize:14}}>{f.initial}</div>
              <div style={{flex:1, minWidth:0}}>
                <div style={{display:'flex', justifyContent:'space-between'}}>
                  <span style={{fontSize:13, fontWeight: f.unread ? 700 : 500, color: active===f.name ? 'var(--accent)' : c.text}}>{f.name}</span>
                  <span style={{fontSize:11, color:c.muted}}>{f.date}</span>
                </div>
                <div style={{fontSize:12, color:c.muted, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{f.last}</div>
              </div>
              {f.unread > 0 && <div style={{width:18, height:18, background:'var(--accent)', borderRadius:'50%', fontSize:11, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, flexShrink:0}}>{f.unread}</div>}
            </div>
          ))}
        </div>
      </div>
      <div style={{flex:1, display:'flex', flexDirection:'column'}}>
        <div style={{padding:'14px 18px', borderBottom:`1px solid ${c.border}`, display:'flex', alignItems:'center', gap:10, background:c.card}}>
          <div style={{width:32, height:32, borderRadius:'50%', background:friend?.color||'var(--accent)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700, fontSize:13}}>{friend?.initial}</div>
          <span style={{fontSize:14, fontWeight:700, color:c.text}}>{active}</span>
        </div>
        <div style={{flex:1, overflowY:'auto', padding:'16px 18px', display:'flex', flexDirection:'column', gap:10}}>
          {(msgs[active]||[]).map((m, i) => (
            <div key={i} style={{display:'flex', justifyContent: m.from==='alice' ? 'flex-end' : 'flex-start', gap:8, alignItems:'flex-end'}}>
              {m.from !== 'alice' && <div style={{width:26, height:26, borderRadius:'50%', background:friend?.color||'#999', flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700, fontSize:11}}>{m.from[0].toUpperCase()}</div>}
              <div style={{maxWidth:'68%'}}>
                <div style={{background: m.from==='alice' ? 'var(--accent)' : c.bubble, color: m.from==='alice' ? '#fff' : c.text, borderRadius: m.from==='alice' ? '12px 12px 3px 12px' : '12px 12px 12px 3px', padding:'8px 12px', fontSize:13, lineHeight:1.45}}>{m.text}</div>
                <div style={{fontSize:10, color:c.muted, marginTop:3, textAlign: m.from==='alice' ? 'right' : 'left'}}>{m.time}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{padding:'12px 16px', borderTop:`1px solid ${c.border}`, display:'flex', gap:8, background:c.card}}>
          <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder={`Message ${active}…`}
            style={{flex:1, border:`1px solid ${c.border}`, borderRadius:22, padding:'9px 16px', fontSize:13, background:c.input, color:c.text, outline:'none'}} />
          <button onClick={send} style={{background:'var(--accent)', color:'#fff', border:'none', borderRadius:22, padding:'9px 18px', fontSize:13, fontWeight:600, cursor:'pointer'}}>Send</button>
        </div>
      </div>
    </div>
  );
};

const friendStyles = {
  card: { padding:'14px', borderRadius:10 },
  tab: { padding:'10px 14px', border:'none', cursor:'pointer', fontSize:13, transition:'all 0.15s', whiteSpace:'nowrap' },
  msgBtn: { background:'var(--accent)', color:'#fff', border:'none', borderRadius:6, padding:'5px 12px', fontSize:12, fontWeight:600, cursor:'pointer' },
  removeBtn: { background:'transparent', color:'oklch(55% 0.2 25)', border:'1px solid oklch(85% 0.08 25)', borderRadius:6, padding:'5px 10px', fontSize:12, fontWeight:600, cursor:'pointer' },
  blockBtn: { background:'transparent', color:'oklch(52% 0.01 250)', border:'1px solid oklch(85% 0.005 250)', borderRadius:6, padding:'5px 10px', fontSize:12, cursor:'pointer' },
};

Object.assign(window, { Friends, Chat });
